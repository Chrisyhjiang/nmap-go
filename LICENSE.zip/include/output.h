#pragma once
#include <string>
#include <vector>

namespace Output {
    void print_results(const std::string& target, const std::vector<int>& open_ports);
}

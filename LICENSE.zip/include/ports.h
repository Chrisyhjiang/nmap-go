#ifndef PORTS_H
#define PORTS_H

#include <unordered_map>
#include <string>

extern std::unordered_map<int, std::string> commonPorts;

#endif // PORTS_H
